# НМТ Навчання (рідний Android-додаток)
Завантаж усі файли в репозиторій. Файл `.github/workflows/build.yml` створи вручну (Add file → Create new file, у назві вкажи шлях). Через 5–10 хв у Releases з’явиться NMT.apk.
